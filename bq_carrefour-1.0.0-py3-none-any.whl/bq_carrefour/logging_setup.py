import logging
import sys

def setup_logger(name=__name__, level=logging.INFO, stream=sys.stdout, fmt=None):
    fmt = fmt or "%(asctime)s %(levelname)s [%(name)s] %(message)s"
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter(fmt))
    logger = logging.getLogger(name)
    logger.setLevel(level)
    # evitar múltiples handlers si se llama varias veces
    if not logger.handlers:
        logger.addHandler(handler)
    return logger