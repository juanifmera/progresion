
__title__ = "Bigquery manager"
__description__ = "Internal Code to deal with BigQuery"
__version__ = "1.00.0"
__build__ = 0x01000
__author__ = "Federico Gonzalez"
__author_email__ = "federico_gonzalez_1_1@carrefour.com"
__license__ = "Apache-2.0"
__copyright__ = "Copyright Federico Gonzalez"