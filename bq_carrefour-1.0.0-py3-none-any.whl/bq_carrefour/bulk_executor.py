from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

logger = logging.getLogger("bulk_bq")

class BulkBQExecutor:
    """Ejecuta múltiples jobs de BigQuery en paralelo usando MethodBQ."""

    def __init__(self, bq_manager, max_workers: int = 4):
        self.bq_manager = bq_manager
        self.max_workers = max_workers

    def run_bulk(self, jobs: list[dict]):
        """
        jobs: lista de diccionarios con:
            {
                "df": DataFrame,
                "table_id": str,
                "mode": "append"|"update"|"merge",
                "primary_keys": list[str] (opcional)
            }
        """
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [executor.submit(self._process_job, job) for job in jobs]
            for future in as_completed(futures):
                # Aquí podrías capturar resultados si necesitas
                pass

    def _process_job(self, job_params: dict):
        try:
            self.bq_manager.upsert_df_to_bigquery(**job_params)
            logger.info(f"Tabla {job_params['table_id']} procesada exitosamente.")
        except Exception as e:
            logger.error(f"Error procesando {job_params['table_id']}: {e}")
