import functools
import logging
import time
from typing import Callable, Any

logger = logging.getLogger("BigqueryManager")

def redact_args(args, kwargs, redact_keys=("password", "secret", "token")):
    """Redactar valores sensibles por clave (simple)."""
    safe_kwargs = {}
    for k, v in kwargs.items():
        if any(r in k.lower() for r in redact_keys):
            safe_kwargs[k] = "<REDACTED>"
        else:
            safe_kwargs[k] = v
    # args handling could be added if needed
    return args, safe_kwargs

def log_calls(level=logging.DEBUG, show_result=True):
    """
    Decorador que loggea entrada/salida, duración y excepciones.
    Uso: @log_calls() o @log_calls(level=logging.INFO)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            name = f"{func.__module__}.{func.__qualname__}"
            a, kw = redact_args(args, kwargs)
            logger.log(level, "ENTER %s args=%s kwargs=%s", name, a, kw)
            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                duration = (time.perf_counter() - start) * 1000.0
                if show_result:
                    logger.log(level, "EXIT  %s duration=%.2fms result=%r", name, duration, result)
                else:
                    logger.log(level, "EXIT  %s duration=%.2fms", name, duration)
                return result
            except Exception:
                duration = (time.perf_counter() - start) * 1000.0
                logger.exception("EXCEPT %s duration=%.2fms", name, duration)
                raise
        return wrapper
    return decorator
