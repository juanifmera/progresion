import pandas as pd
from google.cloud import bigquery
from google.api_core.exceptions import NotFound
from google.cloud.exceptions import NotFound
import time
from .logging_decorators import log_calls
from concurrent.futures import ThreadPoolExecutor


class BigQueryManager:
    """Clase para gestionar operaciones de BigQuery sobre una tabla específica."""

    def __init__(self, client: bigquery.Client, project: str, dataset: str, table: str):
        self.client = client
        self.project = project
        self.dataset = dataset
        self.table = table

    @property
    def table_id(self) -> str:
        """Devuelve el identificador completo de la tabla."""
        return f"{self.project}.{self.dataset}.{self.table}"

    @log_calls()
    def table_exists(self) -> bool:
        """Verifica si la tabla existe en BigQuery."""
        try:
            self.client.get_table(self.table_id)
            return True
        except NotFound:
            return False
    
    @log_calls()
    def schema_exists(self) -> bool:
        """Verifica si el esquema de la tabla existe en BigQuery."""
        try:
            self.client.get_table(self.table_id).schema
            return True
        except NotFound:
            return False
    

    @log_calls()
    def create_table(self, schema: list, table_name: str = None):
        """
        Crea una nueva tabla en BigQuery con el esquema proporcionado.
        Si existe la columna 'fecha_run', crea la tabla particionada por día.
        """
        table_id = table_name or self.table_id

        table = bigquery.Table(table_id, schema)

        # Chequeo de particionamiento
        if any(field.name == 'fecha_run' for field in schema):
            table.time_partitioning = bigquery.TimePartitioning(
                type_=bigquery.TimePartitioningType.DAY,
                field='fecha_run'
            )

        try:
            table = self.client.create_table(table)  # Devuelve el objeto Table creado
            return table
        except Exception as e:
            # Con @log_calls(), la excepción ya se loguea automáticamente
            raise RuntimeError(f"No se pudo crear la tabla {table_id}: {e}") from e


class MethodBQ():

    def __init__(self, project: str):
        self.client = bigquery.Client(project=project)
    
    @log_calls()
    def upsert_df_to_bigquery(
        self,
        df: pd.DataFrame,
        table_id: str,
        primary_keys: list[str] = None,
        mode: str = "merge"  # opciones: "append", "update", "merge"
    ):
        if df.empty:
            return
        if mode in ("update", "merge") and not primary_keys:
            return

        if mode == "append":
            self._append(df, table_id)
        elif mode == "update":
            self._update(df, table_id, primary_keys)
        elif mode == "merge":
            self._merge(df, table_id, primary_keys)
        else:
            raise ValueError(f"Modo '{mode}' no soportado. Usa 'append', 'update' o 'merge'.")


    @log_calls()
    def _append(self, df: pd.DataFrame, table_id: str):
        job_config = bigquery.LoadJobConfig(write_disposition="WRITE_APPEND")
        self.client.load_table_from_dataframe(df, table_id, job_config=job_config).result()

    @log_calls()
    def _update(self, df, table_id: str, primary_keys: list[str]):
        # Para update, creamos tabla temporal y ejecutamos MERGE solo para actualizar
        target_table = self.client.get_table(table_id)
        df_aligned = self._align_types(df, target_table.schema)
        temp_table_id = self._create_temp_table(df_aligned, target_table.schema, table_id)
        update_cols = [f.name for f in target_table.schema if f.name not in primary_keys]
        on_clause = " AND ".join([f"T.{key} = S.{key}" for key in primary_keys])
        update_set_clause = ", ".join([f"T.{col} = S.{col}" for col in update_cols])
        merge_sql = f"""
        MERGE `{table_id}` AS T
        USING `{temp_table_id}` AS S
        ON {on_clause}
        WHEN MATCHED THEN
          UPDATE SET {update_set_clause}
        """
        self.client.query(merge_sql).result()
        self._delete_temp_table(temp_table_id)

    @log_calls()
    def _merge(self, df: pd.DataFrame, table_id: str,primary_keys: list[str]):
        # Upsert completo (insert + update)
        target_table = self.client.get_table(table_id)
        df_aligned = self._align_types(df, target_table.schema)
        temp_table_id = self._create_temp_table(df_aligned, target_table.schema, table_id)
        update_cols = [f.name for f in target_table.schema if f.name not in primary_keys]
        on_clause = " AND ".join([f"T.{key} = S.{key}" for key in primary_keys])
        update_condition_clause = " OR ".join([f"T.{col} IS DISTINCT FROM S.{col}" for col in update_cols])
        update_set_clause = ", ".join([f"T.{col} = S.{col}" for col in update_cols])
        insert_cols = ", ".join(df.columns)
        insert_values = ", ".join([f"S.{col}" for col in df.columns])
        merge_sql = f"""
        MERGE `{table_id}` AS T
        USING `{temp_table_id}` AS S
        ON {on_clause}
        WHEN MATCHED AND ({update_condition_clause}) THEN
          UPDATE SET {update_set_clause}
        WHEN NOT MATCHED THEN
          INSERT ({insert_cols})
          VALUES ({insert_values})
        """
        self.client.query(merge_sql).result()
        self._delete_temp_table(temp_table_id)


    @log_calls()
    def _create_temp_table(self, df: pd.DataFrame, schema: list, table_id: str) -> str:
        project, dataset, _ = table_id.split('.')
        temp_table_id = f"{project}.{dataset}._staging_{int(time.time())}"
        job_config = bigquery.LoadJobConfig(schema=schema, write_disposition="WRITE_TRUNCATE")
        self.client.load_table_from_dataframe(df, temp_table_id, job_config=job_config).result()
        return temp_table_id
    
    @log_calls()
    def _delete_temp_table(self, table_id: str):
        try:
            self.client.delete_table(table_id, not_found_ok=True)
        except Exception:
            return
    
    @log_calls()
    def _align_types(self, df: pd.DataFrame, schema: list) -> pd.DataFrame:
        df_aligned = df.copy()

        for field in schema:
            if field.name in df_aligned.columns:
                if field.field_type in ('DATE', 'DATETIME'):
                    df_aligned[field.name] = pd.to_datetime(df_aligned[field.name])
                elif field.field_type in ('INTEGER', 'INT64', 'FLOAT', 'FLOAT64', 'NUMERIC', 'BIGNUMERIC'):
                    df_aligned[field.name] = pd.to_numeric(df_aligned[field.name], errors='coerce')
        return df_aligned
    
class SchemaGenerator:
    """Responsable de gestionar y generar esquemas de DDL."""
    def __init__(self, schema_filepath: str):
        self.predefined_schemas = self._load_schemas_from_yaml(schema_filepath)

    def _load_schemas_from_yaml(self, filepath: str) -> dict:
        """Carga esquemas predefinidos desde un archivo YAML."""
        try:
            with open(filepath, 'r') as f:
                # Cargar el YAML y asegurarse de que devuelve un diccionario vacío si está vacío
                yaml_schemas = yaml.safe_load(f) or {}
            
            bq_schemas = {}
            for table, fields in yaml_schemas.items():
                bq_schemas[table.lower()] = [bigquery.SchemaField.from_api_repr(field) for field in fields]
            return bq_schemas
        except FileNotFoundError:
            logging.warning(f"Archivo de esquemas '{filepath}' no encontrado. Se procederá con inferencia.")
            return {}

    def get_schema(self, table_name: str) -> list | None:
        """Obtiene un esquema predefinido si existe, buscando por nombre de tabla en minúsculas."""
        return self.predefined_schemas.get(table_name.lower())